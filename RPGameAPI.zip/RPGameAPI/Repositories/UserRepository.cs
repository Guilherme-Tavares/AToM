﻿using RPGameAPI.Models;
using RPGameAPI.Utils;
using MySql.Data.MySqlClient;

namespace RPGameAPI.Repositories
{
    public class UserRepository
    {
        public void Create(User user)
        {
            try
            {
                var query = "INSERT INTO usuario (nome, licenca) VALUES (@name, @license)";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@name", user.Name);
                command.Parameters.AddWithValue("@license", user._license);
                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public List<User> GetAll()
        {
            try
            {
                var users = new List<User>();
                var query = "SELECT * FROM usuario";
                var command = new MySqlCommand(query, Connection.Connect());
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    users.Add(new User
                    {
                        _id = reader.GetInt32("id_usuario"),
                        Name = reader.GetString("nome"),
                        _license = reader.GetString("licenca")
                    });
                }
                return users;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public int GetIdByLicense(string license)
        {
            try
            {
                var query = "SELECT id_usuario FROM usuario WHERE licenca = @license";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@license", license);
                int id = 0;
                using var reader = command.ExecuteReader();
                if (reader.Read())
                    id = reader.GetInt32("id_usuario");
                return id;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public bool VerifyLicense(string license)
        {
            try
            {
                var users = GetAll();
                return !users.Any(u => u._license == license);
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public User GetByLicense(string license)
        {
            try
            {
                if (VerifyLicense(license))
                    throw new Exception("Licença não registrada.");

                var query = "SELECT * FROM usuario WHERE licenca = @license";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@license", license);
                var user = new User();

                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    user._id = reader.GetInt32("id_usuario");
                    user.Name = reader.GetString("nome");
                    user._license = reader.GetString("licenca");
                }
                return user;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public void UpdateName(User user)
        {
            try
            {
                var query = "UPDATE usuario SET nome = @name WHERE usuario.licenca = @license";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@name", user.Name);
                command.Parameters.AddWithValue("@license", user._license);
                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public void DeleteByLicense(string license)
        {
            try
            {
                var query = "DELETE FROM usuario WHERE usuario.licenca = @license";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@license", license);
                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }
    }
}
