﻿using RPGameAPI.Models;
using RPGameAPI.Utils;
using MySql.Data.MySqlClient;

namespace RPGameAPI.Repositories
{
    public class CharacterRepository
    {
        private readonly UserRepository _userRepo = new();

        public void Create(Character character, User user)
        {
            try
            {
                var query = "INSERT INTO personagem (fk_id_usuario, nome, genero, raca, classe) VALUES (@user_id, @name, @gender, @race, @class)";
                var command = new MySqlCommand(query, Connection.Connect());

                command.Parameters.AddWithValue("@user_id", user._id);
                command.Parameters.AddWithValue("@name", character._name);
                command.Parameters.AddWithValue("@gender", character._gender);
                command.Parameters.AddWithValue("@race", character._race);
                command.Parameters.AddWithValue("@class", character._class);

                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public List<Character> GetByUser(User user)
        {
            try
            {
                var characters = new List<Character>();

                var query = "SELECT * FROM personagem WHERE personagem.fk_id_usuario = @user_id";
                var command = new MySqlCommand(query, Connection.Connect());

                int userId = _userRepo.GetIdByLicense(user._license);
                command.Parameters.AddWithValue("@user_id", userId);

                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    characters.Add(new Character
                    {
                        _id = reader.GetInt32("id_personagem"),
                        _fkUser = reader.GetInt32("fk_id_usuario"),
                        _user = user,
                        _name = reader.GetString("nome"),
                        _gender = reader.GetChar("genero"),
                        _race = reader.GetString("raca"),
                        _class = reader.GetString("classe"),
                        _level = reader.GetInt32("nivel"),
                        _experience = reader.GetInt32("experiencia"),
                        _money = reader.GetInt32("dinheiro"),
                        _fkArea = reader.GetInt32("fk_id_localidade")
                    });
                }

                return characters;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }

        public void DeleteById(int characterId)
        {
            try
            {
                var query = "DELETE FROM personagem WHERE id_personagem = @character_id";
                var command = new MySqlCommand(query, Connection.Connect());
                command.Parameters.AddWithValue("@character_id", characterId);
                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            finally { Connection.CloseConnection(); }
        }
    }
}
