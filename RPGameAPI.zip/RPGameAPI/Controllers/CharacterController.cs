﻿using RPGameAPI.Models;
using RPGameAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace RPGameAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CharacterController : ControllerBase
    {
        private readonly CharacterRepository _charRepo = new();
        private readonly UserRepository _userRepo = new();

        [HttpPost]
        public IActionResult Create([FromQuery] string license, [FromBody] Character character)
        {
            try
            {
                var user = _userRepo.GetByLicense(license);
                _charRepo.Create(character, user);
                return Created("", character);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("usuario/{license}")]
        public ActionResult<List<Character>> GetByUser(string license)
        {
            try
            {
                var user = _userRepo.GetByLicense(license);
                var personagens = _charRepo.GetByUser(user);
                return Ok(personagens);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteById(int id)
        {
            _charRepo.DeleteById(id);
            return NoContent();
        }
    }
}
