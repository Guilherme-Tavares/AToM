﻿using RPGameAPI.Models;
using RPGameAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace RPGameAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserRepository _userRepo = new();

        [HttpPost]
        public IActionResult Create([FromBody] User user)
        {
            _userRepo.Create(user);
            return Created("", user);
        }

        [HttpGet]
        public ActionResult<List<User>> GetAll()
        {
            var users = _userRepo.GetAll();
            return Ok(users);
        }

        [HttpGet("id/{license}")]
        public ActionResult<int> GetIdByLicense(string license)
        {
            int id = _userRepo.GetIdByLicense(license);
            return Ok(id);
        }

        [HttpGet("verificar/{license}")]
        public ActionResult<bool> VerifyLicense(string license)
        {
            bool available = _userRepo.VerifyLicense(license);
            return Ok(available);
        }

        [HttpGet("licenca/{license}")]
        public ActionResult<User> GetByLicense(string license)
        {
            try
            {
                var user = _userRepo.GetByLicense(license);
                return Ok(user);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("atualizar-nome")]
        public IActionResult UpdateName([FromBody] User user)
        {
            _userRepo.UpdateName(user);
            return NoContent();
        }

        [HttpDelete("licenca/{license}")]
        public IActionResult DeleteByLicense(string license)
        {
            _userRepo.DeleteByLicense(license);
            return NoContent();
        }
    }
}
