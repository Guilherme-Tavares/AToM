﻿namespace RPGameAPI.Models
{
    public class Character
    {
        public int _id { get; set; }
        public int _fkUser { get; set; }
        public User _user { get; set; } = new();
        public string _name { get; set; } = string.Empty;
        public char _gender { get; set; }
        public string _race { get; set; } = string.Empty;
        public string _class { get; set; } = string.Empty;
        public int _level { get; set; }
        public int _experience { get; set; }
        public int _money { get; set; }
        public int _fkArea { get; set; }
    }
}
