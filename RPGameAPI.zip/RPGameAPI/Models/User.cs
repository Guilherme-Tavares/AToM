﻿namespace RPGameAPI.Models
{
    public class User
    {
        public int _id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string _license { get; set; } = string.Empty;
    }
}
